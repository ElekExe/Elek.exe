﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Guna;
using CzkAPI;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;
namespace Advanced_Executor
{
    public partial class ScriptHub : Form
    {
        public ScriptHub()
        {
            InitializeComponent();
        }

        private void guna2Button5_Click(object sender, EventArgs e)
        {
            this.Hide();
        }

        private void guna2Button6_Click(object sender, EventArgs e)
        {
            WindowState = FormWindowState.Minimized;
        }

        private void guna2Button2_Click(object sender, EventArgs e)
        {
            CzkAPI.CzkFUNC.ExecuteScript("loadstring(game:HttpGet('https://raw.githubusercontent.com/EdgeIY/infiniteyield/master/source'))()");
        }

        private void guna2Button1_Click(object sender, EventArgs e)
        {
            CzkAPI.CzkFUNC.ExecuteScript("loadstring(game:HttpGet(\"https://raw.githubusercontent.com/7GrandDadPGN/VapeV4ForRoblox/main/NewMainScript.lua\", true))()");
        }

        private void guna2Button3_Click(object sender, EventArgs e)
        {
            CzkAPI.CzkFUNC.ExecuteScript("loadstring(game:HttpGet('https://raw.githubusercontent.com/elliexmln/PrizzLife/main/pladmin.lua'))()");
        }

        private void label5_Click(object sender, EventArgs e)
        {

        }

        private void guna2Button4_Click(object sender, EventArgs e)
        {
            CzkAPI.CzkFUNC.ExecuteScript("getgenv().Team = \"Pirates\"\r\ngetgenv().FixCrash = false -- Turn it On For Hopping Server, Improve Performance But Silent Aim On Mob And Player\r\ngetgenv().FixCrash2 = false -- Turn it On For Hopping Server, Improve Performance But Will Remove Speed Changer\r\nloadstring(game:HttpGet(\"https://api.luarmor.net/files/v3/loaders/3b2169cf53bc6104dabe8e19562e5cc2.lua\"))()");
        }

        private void guna2Button7_Click(object sender, EventArgs e)
        {
            CzkAPI.CzkFUNC.ExecuteScript("loadstring(game:HttpGet(\"https://raw.githubusercontent.com/AhmadV99/Speed-Hub-X/main/Speed%20Hub%20X.lua\", true))()");
        }

        private void guna2Button8_Click(object sender, EventArgs e)
        {
            CzkAPI.CzkFUNC.ExecuteScript("loadstring(game:HttpGet(\"https://raw.githubusercontent.com/Joystickplays/psychic-octo-invention/main/yarhm.lua\", false))()");
        }

        private void guna2Button9_Click(object sender, EventArgs e)
        {
            CzkAPI.CzkFUNC.ExecuteScript("loadstring(game:HttpGet('http://scripts.projectauto.xyz/AutoRobV5'))()");
        }

        private void guna2Button10_Click(object sender, EventArgs e)
        {
            CzkAPI.CzkFUNC.ExecuteScript("loadstring(game:HttpGet('https://api.luarmor.net/files/v3/loaders/2529a5f9dfddd5523ca4e22f21cceffa.lua'))()");
        }

        private void guna2Button11_Click(object sender, EventArgs e)
        {
            CzkAPI.CzkFUNC.ExecuteScript("loadstring(game:HttpGet(\"https://raw.githubusercontent.com/Prosexy/Demonic-HUB-V2/main/DemonicHub_V2.lua\", true))()");
        }

        private void guna2Button12_Click(object sender, EventArgs e)
        {
            CzkAPI.CzkFUNC.ExecuteScript("loadstring(game:HttpGet(\"https://raw.githubusercontent.com/KINGHUB01/BlackKing-obf/main/Doors%20Blackking%20And%20BobHub\"))()");
        }

        private void guna2Button13_Click(object sender, EventArgs e)
        {
            CzkAPI.CzkFUNC.ExecuteScript("loadstring(game:HttpGet(\"https://raw.githubusercontent.com/cool5013/TBO/main/TBOscript\"))();");
        }

        private void guna2Button14_Click(object sender, EventArgs e)
        {
            CzkAPI.CzkFUNC.ExecuteScript("loadstring(game:HttpGet(\"https://raw.githubusercontent.com/SoyAdriYT/Bakugan/refs/heads/main/Games/Blade%20Ball.lua\"))()");
        }

        private void guna2Button15_Click(object sender, EventArgs e)
        {
            CzkAPI.CzkFUNC.ExecuteScript("loadstring(game:HttpGet(\"https://raw.githubusercontent.com/ttwizz/Open-Aimbot/master/source.lua\", true))()");
        }

        private void guna2Button16_Click(object sender, EventArgs e)
        {
            CzkAPI.CzkFUNC.ExecuteScript("loadstring(game:HttpGet(\"https://raw.githubusercontent.com/KazeOnTop/Rice-Anti-Afk/main/Wind\", true))()");
        }

        private void guna2Button17_Click(object sender, EventArgs e)
        {
            CzkAPI.CzkFUNC.ExecuteScript("--[[\r\n\tWARNING: Heads up! This script has not been verified by ScriptBlox. Use at your own risk!\r\n]]\r\nloadstring(game:HttpGet(\"https://raw.githubusercontent.com/XNEOFF/FlyGuiV3/main/FlyGuiV3.txt\"))()");
        }

        private void guna2Button18_Click(object sender, EventArgs e)
        {
            CzkAPI.CzkFUNC.ExecuteScript("--[[\r\n\tWARNING: Heads up! This script has not been verified by ScriptBlox. Use at your own risk!\r\n]]\r\nloadstring(game:HttpGet(\"https://raw.githubusercontent.com/Blukez/Scripts/main/UTG%20V3%20RAW\"))()");
        }

        private void guna2Button19_Click(object sender, EventArgs e)
        {
            Form1 mainForm = new Form1();
            mainForm.Show();
            this.Hide();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }
    }
}
