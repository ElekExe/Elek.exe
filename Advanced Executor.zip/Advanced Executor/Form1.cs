﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml.Linq;
using Advanced_Executor.Properties;
using CzkAPI;
using Guna;
using Guna.UI2.WinForms;
using Newtonsoft.Json.Linq;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;
namespace Advanced_Executor
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            InjectionStatus.Start();

            Editor.Navigate(new Uri(string.Format("file:///{0}/Monaco/index.html", Directory.GetCurrentDirectory())));

            SearchTextBox.KeyPress += SearchTextBox_KeyPress;
            SearchTextBox.SelectAll();

            SearchTextBox.Text = "Script";
            SearchScripts(SearchTextBox.Text);
            SearchTextBox.Text = "";
        }

        #region scripthub ahh stuff
        private void SearchTextBox_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)Keys.Enter)
            {
                e.Handled = true;
                SearchScripts(SearchTextBox.Text);
            }
        }

        private async void SearchScripts(string searchQuery)
        {
            flowLayoutPanel1.Controls.Clear();
            flowLayoutPanel1.FlowDirection = FlowDirection.LeftToRight;
            flowLayoutPanel1.WrapContents = true;

            try
            {
                using (HttpClient client = new HttpClient())
                {
                    string apiUrl = $"https://scriptblox.com/api/script/search?q={Uri.EscapeDataString(searchQuery)}&mode=free&max=20";
                    HttpResponseMessage response = await client.GetAsync(apiUrl);

                    if (response.IsSuccessStatusCode)
                    {
                        string responseBody = await response.Content.ReadAsStringAsync();

                        JObject jsonResponse = JObject.Parse(responseBody);
                        JArray scripts = (JArray)jsonResponse["result"]["scripts"];

                        if (scripts != null && scripts.Count > 0)
                        {
                            foreach (var script in scripts)
                            {
                                await CreateScriptPanel(script);
                            }


                        }
                        else
                        {
                            MessageBox.Show("No scripts found for the given search query.", "No Results", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        }
                    }
                    else if (response.StatusCode == HttpStatusCode.NotFound)
                    {
                        MessageBox.Show("The requested resource was not found. Please check the API endpoint or your search query.", "Not Found Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                    else
                    {
                        MessageBox.Show($"Error: {response.StatusCode} - {response.ReasonPhrase}", "ScriptBlox API Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error: {ex.Message}", "ScriptBlox API Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private async Task CreateScriptPanel(JToken script)
        {
            Guna2Panel scriptPanel = new Guna2Panel
            {
                Width = 212,
                Height = 256,
                BorderRadius = 10,
                BorderColor = Color.FromArgb(30, 30, 30),
                BorderThickness = 1,
                FillColor = Color.Black,
                Margin = new Padding(10)
            };
            PictureBox scriptImage = new PictureBox
            {
                Width = 184,
                Height = 140,
                SizeMode = PictureBoxSizeMode.Zoom,
                Location = new Point(11, 7)
            };

            string imageUrl = script["game"]?["imageUrl"]?.ToString() ?? "";
            if (!string.IsNullOrEmpty(imageUrl))
            {
                try
                {
                    using (HttpClient httpClient = new HttpClient())
                    {
                        byte[] imageData = await httpClient.GetByteArrayAsync(imageUrl);
                        using (MemoryStream ms = new MemoryStream(imageData))
                        {
                            Image originalImage = Image.FromStream(ms);
                            scriptImage.Image = RoundCorners(originalImage, 10);
                        }
                    }
                }
                catch (Exception ex)
                {
                    Console.WriteLine($"Error loading image: {ex.Message}");
                    Image defaultimage = Properties.Resources.ERROR_LOGO; ;
                    scriptImage.Image = RoundCorners(defaultimage, 10);
                }
            }

            Label scriptName = new Label
            {
                Text = script["title"]?.ToString() ?? "Untitled Script",
                ForeColor = Color.DarkGray,
                Font = new Font("Arial", 10, FontStyle.Bold),
                Location = new Point(7, 155),
                Width = 170,
                Height = 35,
                TextAlign = ContentAlignment.MiddleLeft,
                BackColor = Color.Transparent
            };

            Label verifiedLabel = new Label
            {
                Text = script["verified"]?.ToObject<bool>() == true ? "Verified" : "Unverified",
                ForeColor = script["verified"]?.ToObject<bool>() == true ? Color.DarkGray : Color.DarkGray,
                Font = new Font("Arial", 8, FontStyle.Bold),
                Location = new Point(7, 187),
                Width = 170,
                TextAlign = ContentAlignment.MiddleLeft,
                BackColor = Color.Transparent
            };

            Guna2Button executeButton = new Guna2Button
            {
                Image = Resources.play_button_arrowhead,
                ImageSize = new Size(10, 10),
                ForeColor = Color.DarkGray,
                FillColor = Color.FromArgb(10, 10, 10),
                PressedColor = Color.FromArgb(10, 10, 10),
                Size = new Size(35, 28),
                BorderRadius = 5,
                Animated = true,
                Location = new Point(5, 224)
            };

            executeButton.Click += (s, e) =>
            {
                string scriptContent = script["script"]?.ToString() ?? "";
                CzkAPI.CzkFUNC.ExecuteScript(scriptContent);
            };

            Guna2Button copyButton = new Guna2Button
            {
                Image = Resources.copy,
                ImageSize = new Size(10, 10),
                ForeColor = Color.DarkGray,
                FillColor = Color.FromArgb(10, 10, 10),
                PressedColor = Color.FromArgb(10, 10, 10),
                Size = new Size(35, 28),
                BorderRadius = 5,
                Animated = true,
                Location = new Point(46, 224)
            };

            copyButton.Click += (s, e) =>
            {
                string scriptContent = script["script"]?.ToString() ?? "";
                Clipboard.SetText(scriptContent);
            };

            scriptPanel.Controls.Add(scriptImage);
            scriptPanel.Controls.Add(scriptName);
            scriptPanel.Controls.Add(verifiedLabel);
            scriptPanel.Controls.Add(executeButton);
            scriptPanel.Controls.Add(copyButton);

            flowLayoutPanel1.Controls.Add(scriptPanel);
        }

        private void CenterResults()
        {
            int totalWidth = flowLayoutPanel1.Controls.Cast<Control>().Sum(c => c.Width + c.Margin.Horizontal);
            int panelsPerRow = flowLayoutPanel1.Width / (180 + 20); // 180 is panel width, 20 is total horizontal margin
            int leftPadding = (flowLayoutPanel1.Width - (panelsPerRow * (180 + 20))) / 2;

            flowLayoutPanel1.Padding = new Padding(leftPadding, 10, 10, 10);
        }
        //Credits discord.gg/realczk
        private Image RoundCorners(Image image, int cornerRadius)
        {
            Bitmap roundedImage = new Bitmap(image.Width, image.Height);
            using (Graphics g = Graphics.FromImage(roundedImage))
            {
                g.Clear(Color.Transparent);
                g.SmoothingMode = SmoothingMode.AntiAlias;
                using (GraphicsPath path = new GraphicsPath())
                {
                    path.AddArc(0, 0, cornerRadius * 2, cornerRadius * 2, 180, 90);
                    path.AddArc(image.Width - cornerRadius * 2, 0, cornerRadius * 2, cornerRadius * 2, 270, 90);
                    path.AddArc(image.Width - cornerRadius * 2, image.Height - cornerRadius * 2, cornerRadius * 2, cornerRadius * 2, 0, 90);
                    path.AddArc(0, image.Height - cornerRadius * 2, cornerRadius * 2, cornerRadius * 2, 90, 90);
                    path.CloseFigure();
                    g.SetClip(path);
                    g.DrawImage(image, 0, 0, image.Width, image.Height);
                }
            }
            return roundedImage;
        }
        #endregion

        private void guna2Button1_Click(object sender, EventArgs e)
        {
            CzkFUNC.Inject();
        }

        private void guna2Button5_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void guna2Button6_Click(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Minimized;
        }

        private void guna2Button2_Click(object sender, EventArgs e)
        {
            string script = Editor.Document.InvokeScript("getValue").ToString();
            CzkFUNC.ExecuteScript(script);
        }

        private void guna2Button4_Click(object sender, EventArgs e)
        {
            CzkAPI.CzkFUNC.KillRoblox();
        }

        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            
        }

        private void guna2Button3_Click(object sender, EventArgs e)
        {
            Editor.Navigate(new Uri(string.Format("file:///{0}/Monaco/index.html", Directory.GetCurrentDirectory())));
        }

        private void guna2CheckBox1_CheckedChanged(object sender, EventArgs e)
        {
            
        }

        private void guna2Button8_Click(object sender, EventArgs e)
        {
            ScriptHub mainForm = new ScriptHub();
            mainForm.Show();
            this.Hide();
        }

        private void InjectionStatus_Tick(object sender, EventArgs e)
        {
           
            }

        

        private void guna2Button7_Click(object sender, EventArgs e)
        {
            
        }

        private void richTextBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void guna2Panel2_Paint(object sender, PaintEventArgs e)
        {

        }

        private void guna2Button9_Click(object sender, EventArgs e)
        {
            
        }

        private void Status_Click(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void guna2Panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void guna2Button10_Click(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Maximized;
        }

        private void guna2Button7_Click_1(object sender, EventArgs e)
        {
            Executor.BringToFront();
        }

        private void guna2Button8_Click_1(object sender, EventArgs e)
        {
            Scripthub.BringToFront();
        }

        private void SearchTextBox_TextChanged(object sender, EventArgs e)
        {

        }

        private void Status_Click_1(object sender, EventArgs e)
        {

        }

        private void guna2Button11_Click(object sender, EventArgs e)
        {
            OpenFileDialog dialog = new OpenFileDialog();
            dialog.Filter = "Text files | *.txt|Lua files (*.lua)|*.lua|All files (*.*)|*.*";
            if (dialog.ShowDialog() == DialogResult.OK)
            {
                string script = File.ReadAllText(dialog.FileName);
                Editor.Document.InvokeScript("SetValue", new object[] { script });
            }
        }

        private void guna2Button12_Click(object sender, EventArgs e)
        {
            SaveFileDialog saveFileDialog1 = new SaveFileDialog
            {
                Filter = "Lua files (*.lua)|*.lua|Text files (*.txt)|*.txt",
                DefaultExt = "lua",
                Title = "Save Lua or Text File"
            };
        }

        private void guna2Button13_Click(object sender, EventArgs e)
        {

        }
    }
}

